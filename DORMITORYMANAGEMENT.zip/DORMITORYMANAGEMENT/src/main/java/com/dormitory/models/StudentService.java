package com.dormitory.models;

public class StudentService extends User {
    
    public StudentService() {
        this.userType = "STUDENT_SERVICE";
    }
}